Welcome to the Executable folder Please find attached the commands to exectue the relevant excutable files:
NB!! Please do not edit the data.txt it merely stores the puzzles to be solved and their solution
Please note that code was written in C++ on a linux machine. All I have is a linux machine so if possible please do run on a linux kernal, but the code should runable in a windows enviroment too. 
But the run commands provide here are for the linux terminal.
But I have provided the source code if recompaltion is needed.

For the AstarAlgorithm
./AStarAlgorithm

For the Best First Search
./BestFirstSearch

For the HillClimbing
./HillClimbing

For the Breadth Fast
./BreadthFirstSearch
