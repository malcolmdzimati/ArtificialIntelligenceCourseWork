Please find the implementation and the code for each of the executibles, each relevant folder has a make file with 
commands:
make  -- to make the command
make run  -- to run the compiled files
make clean   -- to remove all th .o and executble file

