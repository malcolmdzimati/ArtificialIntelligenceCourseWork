Here is my source code. It is here incase if all other excuting modes fail. I have include a make file which will compile and run the source code.
Could can also be persualed to look at implemenation.

Compilation and execuction are all done in one command: make run
