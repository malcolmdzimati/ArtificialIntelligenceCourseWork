Here are the excuible in .class files are files hee need to be present and the code to execute is:
make run
